package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getHash() {
        String data = "ReiceMorgan12345"; // your unique string
        String checksum = ChecksumUtil.generateSHA256(data);
        return "Hello Reice Morgan, here is your SHA-256 Checksum Value: " + checksum;
    }
}
